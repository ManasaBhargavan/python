
import time
import cx_Oracle
start = time.time()
ora_pwd = os.getenv('oracle_user')
con = cx_Oracle.connect("karthik", ora_pwd, "10.219.34.3/orcl")
#con = cx_Oracle.connect("<uid>", "<pwd>", "<ipaddr>/<sid>") 
# pls provide respective values for uid, pwd before executing this pgm
print ("Connected to ", con.version)
cur = con.cursor()
#cur.arraysize = 100
cur.arraysize = 2000
cur.execute('select * from bigtab')
res = cur.fetchall()
# print res  # uncomment to display the query results
elapsed = (time.time() - start)
print (elapsed, " seconds")
cur.close()
con.close()
print ("Disconnected from Oracle")
