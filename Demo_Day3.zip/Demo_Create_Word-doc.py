import sys
sys.path.append('C:\\Users\karamana\\AppData\\Local\\Programs\\Python\\Python36-32\\python-docx-0.8.6')
import docx
from docx import Document
document = Document()
paragraph = document.add_paragraph('This is the first line of the first paragraph.')
prior_paragraph = paragraph.insert_paragraph_before('Previous Paragraph')
document.add_heading('The REAL meaning of the universe')
document.add_heading('The role of dolphins', level=2)
run = paragraph.add_run('Run example')
run.bold = True
paragraph.add_run('Second Run ex').bold = True
document.add_page_break()
table = document.add_table(rows=2, cols=2)
cell = table.cell(0, 0)
cell.text = 'Row 1, cell 1'
cell1 = table.cell(0, 1)
cell1.text = 'Row 1, cell 2'
document.save('MyFirstDoc.docx')
