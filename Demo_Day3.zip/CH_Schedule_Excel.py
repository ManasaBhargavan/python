#Pls ensure the the excel file is there in the working dir otherwise, need to specify the path for this excel file
#works in 64bit
import os
import sys
sys.path.append('C:\\Users\karamana\\AppData\\Local\\Programs\\Python\Python36-32\\jdcal-1.3\jdcal-1.3')
sys.path.append('C:\\Users\karamana\\AppData\\Local\\Programs\\Python\\Python36-32\\et_xmlfile-1.0.1')
sys.path.append('C:\\Users\karamana\\AppData\\Local\\Programs\\Python\\Python36-32\\openpyxl-2.5.0a3')

import cx_Oracle
#import openpyxl
from openpyxl import Workbook
from openpyxl import load_workbook
from openpyxl import styles
from openpyxl.styles.fonts import Font
#var assignments
wb = Workbook()
sheet = wb.get_sheet_by_name('Sheet') #wb.active
mycell = sheet['A1']
mycell.value = 'Batch Schedule for December 2017 Batches'
#DB connection
ora_pwd = os.getenv('oracle_user') # getting pwd from enmt variable
con = cx_Oracle.connect("karthik", ora_pwd, "10.219.34.3/orcl")
cur_bid = con.cursor()
cur = con.cursor()
input_id = float(input("Enter starting Batch Id: "))
cur_bid.execute("select distinct batch_id from batch_schedule where batch_id > :id", id=input_id)
b_id_ctr=0
bctr = 0
col_coord = ['A','B','C','D','E']
row_coord = 2
for b_id in cur_bid:
#      print (len(cur_bid)) #b_id
      cur.prepare("Select batch_name, course_name, course_duration, to_char(start_date,'DD-Mon-YY' ), to_char(end_date,'DD-Mon-YY' ), lab_description from batch_schedule where batch_id=:id")
      cur.execute(None, {'id': b_id[b_id_ctr]})  #[b_id_ctr]
      print (b_id[b_id_ctr])
      res = cur.fetchone()
      if bctr > 0:
            row_coord = row_coord + 3
      else:
            row_coord = row_coord + 1
      sheet["{0}{1}".format(col_coord[0],str(row_coord))].value=res[0]
      sheet["{0}{1}".format(col_coord[0],str(row_coord))].font=Font(color='000000', bold=True)
      sheet.append(['Course Name', 'Duration in (Days)', 'Start Date', 'End Date', 'Lab Details'])
      row_coord = row_coord + 1
      for num in range(0,5):
            sheet["{0}{1}".format(col_coord[num],str(row_coord))].font=Font(color='000000', bold=True)
      for batch_name, course_name, course_duration,start_date,end_date , lab_description in cur:
            if course_name.split()[-1]=='Test':
                  sheet.append([course_name, course_duration,start_date,end_date,lab_description])
                  row_coord = row_coord + 1
                  for num in range(0,5):
                        sheet["{0}{1}".format(col_coord[num],str(row_coord))].font=Font(color='000000', bold=True)
            else:
                  sheet.append([course_name, course_duration,start_date,end_date,lab_description])
                  row_coord = row_coord + 1
      bctr = bctr + 1
#closing of cursor and connection
cur_bid.close()
cur.close()
con.close()
#saving and closing excel
wb.save("Schedule.xlsx")
wb.close()
